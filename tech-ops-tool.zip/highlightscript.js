// Highlight the "Course Admin" button
$('d2l-menu-item-link[text="Course Admin"] a').css({
  "background-color": "blue",
  "color": "white"
});

// Highlight the "Manage Files" button
$('a.vui-link[href*="manageFiles"]').css({
  "padding": "0 5px",
  "background-color": "blue",
  "color": "white"
});
